// Build the navigation menu
var navList = document.querySelector("#navbar__list");
var Sections = document.querySelectorAll("section");
function createNav() {
  for (let i = 0; i < Sections.length; i++) {
    liElements = document.createElement("li");
    liElements.innerHTML = `<li><a href="#${Sections[i].id}" 
    class="menu__link">Section ${i + 1}  </a>`;
    navList.appendChild(liElements);
  }
}

createNav();

// apply active class to section in viewport
document.addEventListener("scroll", function makeActive() {
  for (let i = 0; i < Sections.length; i++) {
    let location = Sections[2].getBoundingClientRect();
    //console.log(location);
    if (
      Sections[i].getBoundingClientRect().bottom <= 690 &&
      Sections[i].getBoundingClientRect().bottom >= 182
    ) {
      Sections[i].classList.add("your-active-class");
    } else {
      Sections[i].classList.remove("your-active-class");
    }
  }
});

// hide navbar while scrolling
var lastScrollTop;
navbar = document.querySelector("header");
window.addEventListener("scroll", function scrolling() {
  var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  if (scrollTop > lastScrollTop) {
    navbar.style.top = "-80px";
  } else {
    navbar.style.top = "0";
  }
  lastScrollTop = scrollTop;
});

// create scroll button
var scrollbtn = document.createElement("button");

function scrollTop() {
  scrollbtn.innerHTML = "To Top";
  scrollbtn.setAttribute("id", "btnId");
  document.body.appendChild(scrollbtn);
}
scrollTop();

function displaybtn() {
  window.scrollY > 2000
    ? scrollbtn.classList.add("show")
    : scrollbtn.classList.remove("show");
}

window.addEventListener("scroll", displaybtn);

function scrollToUp() {
  if (window.scrollY != 0) {
    window.scrollTo(0, 0);
  }
}

scrollbtn.addEventListener("click", scrollToUp);
