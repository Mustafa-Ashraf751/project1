I do my best to do what was required through a set of steps :
1.make fuction to insert sections li to navlist

2.set the active class style to current section throw determinate the location of section to viewport and creat function to set the class

3.making scrolling smooth through css

4.making the navbar responsive to all devices

5.make the navbar hidden while scrolling

6.make button to move up

I had seen the documentaion and i used the references websites like MDN , W3School.
